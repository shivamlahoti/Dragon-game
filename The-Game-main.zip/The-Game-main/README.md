# The-Game
It is fun game created using C++, which uses multi-threading using one thread for displaying the content on the command-prompt and the other thread waiting for input for initiating the jump. This game have four different type of obstacles which will appear at random during the game.

# Requirement :
-main.cpp\
-additional.cpp\
-display.cpp\
-Makefile\

# To run the Game 
run the command\
$make
